#!/bin/sh
if [ "$1" != "-version" ]; then
  mkdir -p cache
  cp /workspace/scratch/ec0ad557001f/brobot-current/.server/cache/mojang_1.21.8.jar cache/mojang_1.21.8.jar
fi
exec /usr/bin/java "$@"
