#!/bin/sh
if [ "$1" = "-version" ]; then exec /usr/bin/java "$@"; fi
mkdir -p "$PWD/cache"
cp /workspace/scratch/ec0ad557001f/brobot-face-reach/.server/cache/mojang_1.21.8.jar "$PWD/cache/mojang_1.21.8.jar"
exec /usr/bin/java "$@"
