from pathlib import Path
import json,subprocess,hashlib,datetime,os
root=Path('/workspace/scratch/ec0ad557001f');repo=root/'brobot-scoped-search';out=root/'brobot793-validation'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert source=='4de9ef595e60efca1db67e9c020cf8eb804349f3'
files={p:sha(repo/p) for p in subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines() if p.startswith(('src/','scripts/','test/')) or p in ['package.json','package-lock.json']}
plan={'source':source,'declared':now(),'classification':'One selected known failing seed after a prepared gate. Selection is informed by the prior 120-second instrumented diagnostic; this uninstrumented 300-second attempt is separate, not held-out, not full-cohort and not causal comparison. Keep the outcome; no world-attempt replacement.','seed':'1542908414','seconds':300,'files':files,'stages':[]}
def save():out.joinpath('plan.json').write_text(json.dumps(plan,indent=2)+'\n')
def verify():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
 assert all(sha(repo/p)==v for p,v in files.items())
 assert 'java' not in subprocess.check_output(['ps','-eo','comm='],text=True).split()
save();out.joinpath('declaration.json').write_text(json.dumps(plan,indent=2)+'\n')
env=os.environ.copy();env['JAVA_TOOL_OPTIONS']=f'-DbundlerRepoDir={root}/BroBot/.server/runtime-cache'
try:
 for label,args in [('normal17',['scripts/smoke.js']),('known154',['scripts/benchmark-survival.js',f'--repo={repo}','--seed=1542908414','--seconds=300','--label=scoped793-selected'])]:
  verify();record={'label':label,'started':now()};plan['stages'].append(record);save();print('START',label,flush=True)
  log=out/(label+'.log')
  with log.open('w') as stream:p=subprocess.run(['node',*args],cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT)
  record.update(returnCode=p.returncode,finished=now(),logSha256=sha(log));result=None
  for line in log.read_text().splitlines():
   if line.startswith('Detailed result: '):result=Path(line.split(': ',1)[1])
   try:v=json.loads(line)
   except ValueError:continue
   if isinstance(v,dict) and v.get('benchmark')=='Trailhead' and v.get('result'):result=Path(v['result'])
  if result and result.exists():
   raw=json.loads(result.read_text());record.update(result=str(result),passed=raw.get('passed'),rawSha256=sha(result));out.joinpath(label+'.json').write_bytes(result.read_bytes())
  verify();record['cleanupVerified']=True;save();print('RESULT',json.dumps(record),flush=True)
  if label=='normal17' and (p.returncode or not record.get('passed')):raise RuntimeError('Prepared gate failed; selected world not launched')
 plan['completed']=True
except Exception as error:plan['blocked']=str(error);print('BLOCKED',str(error),flush=True)
finally:plan['finished']=now();save()
