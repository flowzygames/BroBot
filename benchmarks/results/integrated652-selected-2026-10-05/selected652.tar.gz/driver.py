import json,hashlib,subprocess,datetime,os,shutil,socket
from pathlib import Path
root=Path('/workspace/scratch/ec0ad557001f');repo=root/'brobot-scout-rations';out=root/'brobot-integrated652-validation';source='f466593ab23a3a0b5ca8a6ffe324486fcfb2591d'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((root/'brobot-scout625-full/plan.json').read_text()).get('finished'),'625 originals must finish first'
out.mkdir(exist_ok=False);declaration=json.loads(Path('/tmp/brobot-integrated652-plan.json').read_text());assert declaration['source']==source
plan={**declaration,'started':now(),'prepared':[],'cases':[],'active':None};files={}
for f in subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines():
 if f.startswith(('src/','scripts/','test/','public/')) or f in ['package.json','package-lock.json']:files[f]=sha(repo/f)
(out/'tested-files.json').write_text(json.dumps({'source':source,'files':files},indent=2)+'\n');(out/'predeclaration.json').write_text(json.dumps(declaration,indent=2)+'\n')
shutil.copyfile(__file__,out/'driver.py')
def save():
 plan['updated']=now();p=out/'plan.tmp';p.write_text(json.dumps(plan,indent=2)+'\n');p.replace(out/'plan.json')
def verify():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
 assert all(sha(repo/f)==v for f,v in files.items())
 assert 'java' not in [s.strip() for s in subprocess.check_output(['ps','-eo','comm='],text=True).splitlines()]
 for port in [25577,25641,25575]:
  with socket.socket() as s:s.settimeout(.3);assert s.connect_ex(('127.0.0.1',port))!=0
 assert shutil.disk_usage(root).free>2*1024**3
save();env=os.environ.copy();env['JAVA_TOOL_OPTIONS']=f'-DbundlerRepoDir={root}/BroBot/.server/runtime-cache'
try:
 for script,label in zip(declaration['preparedGates'],['action-sessions','scout-rations','normal17']):
  verify();log=out/f'{label}.log';plan['active']={'prepared':label};save();print('PREPARED',label,flush=True)
  with log.open('w') as stream:p=subprocess.run(['node',script],cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT)
  path=None
  for line in log.read_text().splitlines():
   if line.startswith('Detailed result: '):path=Path(line.removeprefix('Detailed result: '))
  record={'label':label,'script':script,'returnCode':p.returncode,'finished':now(),'result':str(path) if path else None}
  if path and path.exists():
   raw=json.loads(path.read_text());record.update(passed=raw.get('passed',False),rawSha256=sha(path));shutil.copyfile(path,out/f'{label}.json')
   if label!='normal17':assert raw['commit']==source and raw['dirty']==False
   else:assert len(raw.get('phases',[]))==17
  else:record['passed']=False
  plan['prepared'].append(record);verify();record['cleanupVerified']=True;plan['active']=None;save();print('GATE',json.dumps(record),flush=True)
  if p.returncode or not record['passed']:raise RuntimeError(f'Prepared gate {label} failed; dependent stages never started')
 for seed in declaration['selectedKnownSeeds']:
  verify();log=out/f'{seed}.log';record={'seed':str(seed),'status':'running','started':now(),'attempt':1};plan['cases'].append(record);plan['active']={'seed':str(seed)};save();print('CASE',seed,flush=True)
  with log.open('w') as stream:p=subprocess.run(['node','scripts/benchmark-survival.js',f'--repo={repo}',f'--seed={seed}','--seconds=300','--label=integrated652-selected-diagnostic'],cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT)
  terminal=None
  for line in log.read_text().splitlines():
   try:v=json.loads(line)
   except ValueError:continue
   if isinstance(v,dict) and v.get('benchmark')=='Trailhead' and v.get('result'):terminal=v
  record.update(returnCode=p.returncode,finished=now())
  if terminal:
   record.update(terminal);path=Path(terminal['result']);raw=json.loads(path.read_text());assert raw['commit']==source and not raw['dirty'] and raw['seed']==str(seed) and raw['conditions']['timeBudgetSeconds']==300
   record.update(rawSha256=sha(path),passed=raw['passed']);shutil.copyfile(path,out/f'{seed}.json')
  else:record.update(status='interrupted',passed=None,reason='No terminal result; no retry or substitution')
  verify();record['cleanupVerified']=True;plan['active']=None;save();print('RESULT',json.dumps(record),flush=True)
  if not terminal:raise RuntimeError('Incomplete natural result; preserve original attempt and stop')
 plan['completed']=True
except Exception as error:
 plan['blocked']=str(error);plan['completed']=False;print('BLOCKED',str(error),flush=True);raise
finally:
 plan['finished']=now();save()
