import pathlib,json,subprocess,os,datetime,fcntl,sys
root=pathlib.Path(__file__).resolve().parents[3]
work=root/'dist/scout-novelty/cohort';plan=json.loads((work/'plan.json').read_text())
lock=open(work/'driver.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def check_source():
 if git('rev-parse','HEAD')!=plan['source'] or git('rev-parse','HEAD^{tree}')!=plan['sourceTree'] or git('status','--porcelain'):raise RuntimeError('Frozen source identity or cleanliness changed')
def save():
 tmp=work/'state.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(work/'state.json')
def collect_result(attempt,seed):
 candidates=[]
 for p in (root/'.server/benchmarks').glob('*/result.json'):
  try:r=json.loads(p.read_text())
  except (ValueError,OSError):continue
  if r.get('label')==attempt['label'] and r.get('seed')==seed:candidates.append((p,r))
 if len(candidates)>1:raise RuntimeError('Ambiguous result identity')
 if not candidates:return False
 p,r=candidates[0]
 if r.get('commit')!=plan['source'] or r.get('dirty') is not False:raise RuntimeError('Result source mismatch')
 attempt.update(result=str(p.relative_to(root)),resultStatus=r.get('status'),passed=r.get('passed'),elapsedMs=r.get('elapsedMs'),reason=r.get('reason'),finished=now())
 attempt['status']='completed' if r.get('status') in ['passed','failed'] else 'infrastructure_error'
 return True
check_source()
state=json.loads((work/'state.json').read_text()) if (work/'state.json').exists() else {'source':plan['source'],'started':now(),'status':'running','entries':[{'group':group,'seed':seed,'attempts':[]} for group,key in [('known','knownSeeds'),('original','originalSeeds')] for seed in plan[key]]}
if state['source']!=plan['source']:raise RuntimeError('State source mismatch')
for entry in state['entries']:
 for attempt in entry['attempts']:
  if attempt['status']=='running':
   if not collect_result(attempt,entry['seed']):
    if '--resume-interrupted' not in sys.argv:raise RuntimeError('Incomplete prior attempt; inspect its processes and evidence before explicit recovery')
    attempt.update(status='interrupted',finished=now(),note='Prior execution ended without a final result; partial directory/logs retained')
 if any(a['status']=='completed' for a in entry['attempts']):continue
 if entry['attempts'] and '--resume-interrupted' not in sys.argv:raise RuntimeError('Prior incomplete attempt needs explicit recovery')
 check_source();n=len(entry['attempts'])+1
 label=f"scout1076-full-{entry['group']}-{entry['seed']}-attempt{n}"
 attempt={'label':label,'status':'running','started':now(),'log':f"{entry['group']}-{entry['seed']}-attempt{n}.log"};entry['attempts'].append(attempt);save()
 print(f"START {entry['group']} {entry['seed']} attempt{n}",flush=True)
 env=os.environ.copy();env['JAVA_PATH']=str(root/'dist/scout-novelty/cached-java.sh')
 with open(work/attempt['log'],'w') as log:
  result=subprocess.run(['node','scripts/benchmark-survival.js',f"--seed={entry['seed']}",'--seconds=300',f'--label={label}'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 attempt['exitCode']=result.returncode
 if not collect_result(attempt,entry['seed']):attempt.update(status='interrupted',finished=now(),note='Harness exited without result; inspect retained logs before recovery')
 save();print(f"END {entry['group']} {entry['seed']} {attempt['status']} passed={attempt.get('passed')} elapsedMs={attempt.get('elapsedMs')}",flush=True)
 if attempt['status']!='completed':state['status']='needs_review';save();sys.exit(2)
state.update(status='complete',finished=now());save();print('COHORT COMPLETE',flush=True)
